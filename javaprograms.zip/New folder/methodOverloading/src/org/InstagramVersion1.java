package org;

public class InstagramVersion1 {
	
	void upload()
	{
		System.out.println("image is uploaded");
	}

}
