package org;

public class Test {
	public static void main(String[] args) {
		B ba=new B();
		ba.start();
		//ba.stop();
		
	}

}
