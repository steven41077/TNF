package org;

public class A {
	
	 void start() {
	System.out.println("i am stared coding");

	}
	
	
	
	void stop() {
	
		System.out.println("i am stopped coding");
	}

}
