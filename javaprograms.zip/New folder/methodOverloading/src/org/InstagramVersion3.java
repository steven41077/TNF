package org;

public class InstagramVersion3 extends InstagramVersion2{
	
	
	@Override
	void upload()
	{
		super.upload();
		System.out.println("video is uploaded");
	}
	
	@Override
	void directMessage()
	{
		super.directMessage();
		System.out.println("images also be sent a person");
	}
	
	void story()
	{
		System.out.println("short stories can be sent in a instagram");
	}

}
