package org;

public class Steven {
	public static void main(String[] args) {
		InstagramVersion3 i3=new InstagramVersion3();
		System.out.println("the Beginning");
		System.out.println("======================");
		i3.upload();
		System.out.println("======================");
		i3.directMessage();
		System.out.println("======================");
		i3.story();
		System.out.println("======================");
		System.out.println("the end");
	}

}
