package org;

public class B extends A{
 

	
	@Override
	
      void start() {
		super.start();
		super.stop();
		System.out.println("but i started coding in a class B ");
	}
	
	

}
