package org;

public class InstagramVersion2 extends InstagramVersion1 {
	
	@Override
	void upload()
	{
		super.upload();
		System.out.println("gif is uploaded");
	}
	
	void directMessage()
	{
		System.out.println("text is send a person");
	}

}
