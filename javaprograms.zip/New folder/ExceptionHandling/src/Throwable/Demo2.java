package Throwable;

import java.io.FileReader;

public class Demo2 {
      
	void Readdata()throws Exception {
		FileReader f=new FileReader("steven");
		
	}
	public static void main(String[] args) {
		Demo2 d=new Demo2();
		try {
			d.Readdata();
		} catch (Exception e) {
			System.out.println("file not found exception");
		}
	}

}
