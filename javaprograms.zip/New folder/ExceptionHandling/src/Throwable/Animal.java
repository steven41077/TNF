package Throwable;
import java.io.FileNotFoundException;
import java.io.FileReader;
public class Animal {
 public static void main(String[] args) throws FileNotFoundException {
	 try {
	FileReader r=new FileReader("hello familly members");
	 }
	 catch(FileNotFoundException f)
	 {
		 System.out.println("hi bro");
	 }
}
}
