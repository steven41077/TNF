package org;

public class Demo {
	public static void main(String[] args) {
		System.out.println("Start");
		int[] a= {10,20,30,49};
		try {
		System.out.println(a[3]);
	}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("dabba fellow it is invalid exceptin please try to print with in array");
		}
		System.out.println("end");
	}

}
