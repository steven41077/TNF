package org;
import java.util.Scanner;
public class Test {
	
	public static void main(String[] args) {
	@SuppressWarnings("resource")
	Scanner sc=new Scanner(System.in);	 
	System.out.println("enter the value a:");
	double a=sc.nextDouble();
	System.out.println("enter the value b:"); 
    double b=sc.nextDouble();
	try {
		System.out.println(a/b);//100/200
	}
	catch(Exception e)
	{
		System.out.println("invalid choose man try to see it man once");
	}
	}

}
