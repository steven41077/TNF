package Finally;

public class Output{
	public static void main(String[] args) {
		try {
			int a=5;
			int b=0;
			int c=b/a;//0
			System.out.println("hello");
		}
	    catch(Exception e)
		{
			System.out.println("world");
		}
	}

}
