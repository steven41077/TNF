package Finally;

public class Finall {
	public static void main(String[] args) {
		//System.out.println("Start");
		try {
		int i;
		return;
		}
		catch(Exception e)
		{
			System.out.println("dtgjhkjlkl");//e.getMessage();
			 
		}
		finally
		{
			System.out.println("dfghjk");
		}

	}
	}


