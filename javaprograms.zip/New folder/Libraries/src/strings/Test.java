package strings;

public class Test {
	public static void main(String[] args) {
		//empty representation of a string object
		String s1=new String();
		System.out.println(s1);
		
		System.out.println("---------------------------");
		String s2=new String("java");
		System.out.println(s2);
		System.out.println("---------------------------");
		char [] ch = {'a','p','p','l','e'};
		//converting character [] into string object
		String s3=new String(ch);
		System.out.println(s3.hashCode());

	}

}
