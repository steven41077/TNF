package strings;

public class MethodDemo {
	public static void main(String[] args) {
		String s="Software Developer";
		System.out.println(s.length());//18
		System.out.println("========================================");
		
		System.out.println(s.toUpperCase());//SOFTWARE DEVELOPER
		System.out.println(s.toLowerCase());//software developer
		System.out.println("========================================");
		
		System.out.println(s.startsWith("soft"));//false
		System.out.println(s.startsWith("Soft"));//true
		System.out.println("========================================");
		
		System.out.println(s.endsWith("er"));//true
		System.out.println("========================================");
		
		System.out.println(s.contains("Deve"));
		System.out.println("========================================");
		
		System.out.println(s.concat(" in the form of technology"));
		System.out.println("========================================");
		//string s="Software Developer
		System.out.println(s.charAt(7));//e
		System.out.println("========================================");
		
		System.out.println(s.indexOf('D'));
		System.out.println("========================================");
		
		String s2="java";
		String s3="Java";
		String s4="java";
		System.out.println(s2.equals(s3));//false
		System.out.println(s2.equals(s4));//true
		System.out.println("========================================");
		
		
		System.out.println(s2.equalsIgnoreCase(s3));//true
		System.out.println("========================================");
		System.out.println("========================================");
		
		String v="hello steven";
		System.out.println(v.substring(2,7));//teven
		System.out.println("========================================");
		System.out.println("========================================");
		System.out.println("========================================");
		
		
	}

}
