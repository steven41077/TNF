package strings;

public class Demo {
	public static void main(String[] args) {
		String m=new String("a");
		System.out.println(m);
		System.out.println(m.hashCode());
		System.out.println("-----------------------");
		String s="java";
		String s1="Java";
		System.out.println(s.equals(s1));
		System.out.println(s.equalsIgnoreCase(s1));
	}

}
