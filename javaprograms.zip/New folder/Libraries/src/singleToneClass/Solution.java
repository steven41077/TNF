package singleToneClass;

public class Solution {
	public static void main(String[] args) {
		 Employee obj=Employee.createObject();
		 System.out.println("id: "+obj.id);

}
}