package singleToneClass;

public class Student {
	String name="Stevenson";
	int age =24;
	private static Student st;
	
	private Student()
	{
		System.out.println("students details iss created");
	}
	 public static Student createObj() {
		 if (st==null) {
		 st=new Student();
		 System.out.println("hi hello");
		 
	 }
		 else {
			 System.out.println("bye");
		 }
		return st;
	
	 }
}
