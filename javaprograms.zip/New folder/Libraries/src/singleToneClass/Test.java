package singleToneClass;

public class Test {
	public static void main(String[] args) {
		
		Student st =Student.createObj();
		System.out.println(st.name);
		System.out.println(st.age);
	}

}
