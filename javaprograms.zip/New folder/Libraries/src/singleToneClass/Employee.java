package singleToneClass;

public class Employee {
	int id=25;
	 private static Employee obj;
	 private Employee()
	 {
		 System.out.println("employee id is cereated");
	 }
	 
	 public static  Employee createObject()
	{
		 if(obj==null)
		 {
	obj = new Employee();
	}
		return obj;
	 
	}
}
