package comparingEqual;

public class Student {
	int rollno;
	String name;
	String standard;
	Student(int rollno, String name, String standard) {
		this.rollno = rollno;
		this.name = name;
		this.standard = standard;
	}
   
   public boolean equlas(Object obj)
   {
	   Student s=(Student) obj;
	   return this.rollno==s.rollno && this.name==s.name && this.standard==s.standard;
   }
  public static void main(String[]args) 
 {
	 Student s1=new Student(65,"steven","bacholre");
	 Student s2=new Student(65,"steven","bacholre");
	 //Student s3=new Student(65,"steven","bacholre");
	 
	System.out.println(s1.equals(s2));
	
	
	
	
	
	
	
 }
}
