package comparingEqual;

public class Parents {
	int age;
	String name;
	Parents(int age, String name) {
		this.age = age;
		this.name = name;
	}
	public boolean equals(Object obj) {
		Parents pa=(Parents) obj;
		return this.age==pa.age && this.name==pa.name;
	}
	
   public static void main(String[]args)
   {
	   Parents p=new Parents(76,"krupavaram");
	   Parents p1=new Parents(76,"ram");
	   System.out.println(p.equals(p1));
	   
	   
   }
}
