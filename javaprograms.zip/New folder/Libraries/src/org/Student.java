package org;

public class Student {
	int age;
	String name;
	
	Student(int age,String name)
	{
		this.age=age;
		this.name=name;
		
	}
	@Override
	public String toString()
	{
		return "age:"+this.age+" "+"name:"+this.name+" ";
	}
	
 @Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	@SuppressWarnings("removal")
	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
	}
public static void main(String[]args)
 {
	 Student s1=new Student( 20,"nathanelu");
	 Student s2=new Student( 78, "thanelu");
	 Student s3=new Student( 23,"samel");
	 Student[] s=new Student[3];
			 s[0]=s1;
	         s[1]=s2;
	         s[2]=s3;
	for (int i=0;i<s.length;i++)
	{
		System.out.println(s[i]);
	}
	         
	 
 }

}

