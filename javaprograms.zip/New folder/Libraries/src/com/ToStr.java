package com;

public class ToStr {
	String name;
	ToStr(String name)
	{
		this.name=name;
	}
	public String toString()
	{
		return this.name;
	}
public static void main(String[]args)
{
	ToStr t=new ToStr("steven");
	ToStr t1=new ToStr("stella");
	System.out.println(t);
	System.out.println(t1);
	
	System.out.println(t.toString());
	System.out.println(t1.toString());
}

}
