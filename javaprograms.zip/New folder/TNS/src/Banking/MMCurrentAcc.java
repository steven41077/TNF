package Banking;

//create MMCurrentAcc class
public abstract class MMCurrentAcc extends CurrentAcc {
    public MMCurrentAcc(int accNo, String accNm, float accBal, float creditLimit) {
        super(accNo, accNm, accBal, creditLimit);
    }

    @Override
    public void withdraw(float amount) {
        if (getAccBal() - amount >= getCreditLimit()) {
            accBal -= amount;
        } else {
            System.out.println("Withdrawal not allowed. Insufficient balance and credit limit.");
        }
    }

    @Override
    public String toString() {
        return "MMCurrentAcc{" +
                "accNo=" + getAccNo() +
                ", accNm='" + getAccNm() + '\'' +
                ", accBal=" + getAccBal() +
                ", creditLimit=" + getCreditLimit() +
                '}';
    }
}
