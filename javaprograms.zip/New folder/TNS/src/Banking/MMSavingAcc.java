package Banking;

public abstract class MMSavingAcc extends SavingAcc {
    public MMSavingAcc(int accNo, String accNm, float accBal, boolean isSalaried) {
        super(accNo, accNm, accBal, isSalaried);
    }

    @Override
    public void withdraw(float amount) {
        // Implement withdrawal logic specific to MMSavingAcc
    }

    @Override
    public String toString() {
        // Implement toString method
        return super.toString(); // You can customize this if needed
    }
}