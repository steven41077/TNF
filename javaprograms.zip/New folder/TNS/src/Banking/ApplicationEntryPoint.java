package Banking;

public class ApplicationEntryPoint {
	    public static void main(String[] args) {
	        MMBankFactory bankFactory = new MMBankFactory();
	        
	        // Create a Saving Account
	        SavingAcc savingAcc = bankFactory.getNewSavingAcc(1, "John", 2000, true);
	        savingAcc.withdraw(1500);
	        System.out.println(savingAcc);
	        
	        // Create a Current Account
	        CurrentAcc currentAcc = (CurrentAcc) bankFactory.getNewCurrentAcc(2, "Alice", 5000, 2000);
	        currentAcc.withdraw(3000);
	        System.out.println(currentAcc);
	    }
	

}


