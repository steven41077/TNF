import java.util.Scanner;

public class Country {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the 1st country name");
		String C=sc.nextLine();
		System.out.println("enter the 2nd country name");
		String C1=sc.nextLine();
		System.out.println("enter the 3rd country name");
		String C2=sc.nextLine();
		System.out.println("enter the 4th country name");
		String C3=sc.nextLine();
		System.out.println("enter the 5th country name");
		String C4=sc.nextLine();
		System.out.println(C);
		System.out.println(C1);
		System.out.println(C2);
		System.out.println(C3);
		System.out.println(C4);
		
	}

}
