package com.tnsif.dayeight.interfacedemo;

public interface Bank {
	final  static int MINBAL=5000;
	final static int DEPOSIT_LIMIT=25000;
	public void deposit(int amount);
	public void withdraw(int amount);
	public void checkbalance();
	public void ministatment();
	
	default void show() {
	       System.out.println("hi");
	       
	}
	static void print()
	{
		
	}
	

}