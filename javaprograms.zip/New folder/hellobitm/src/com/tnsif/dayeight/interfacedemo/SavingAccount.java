package com.tnsif.dayeight.interfacedemo;

public class SavingAccount  extends Customer implements Bank{
	private int accNo;
	private int balance;
	
	//constructor
	public SavingAccount(int accNo, int balance) {
		super(name,city);
		this.accNo = accNo;
		this.balance = balance;
	}
	
	//get set method
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	
	public void deposit(int amount) {
		if (amount<0 && amount>DESPOSIT_LIMIT) {
			System.out.println("please deposie valid amount");
		}
		else
		{
			balance+=amount;
			System.out.println("Rs"+amount+" is deposit successfully");
		}
	}
	
	
			
	public void withdraw(int amount)
	if(amount<=balance-MINBAL)
	{
		balance-=amount;
		System.out.println("Rs"+amount+" is withdraw successfully");
	}
	else
	{
          System.out.println("easy ton stror");
	}
	
}}
