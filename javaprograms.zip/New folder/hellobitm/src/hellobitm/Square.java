package hellobitm;

public class Square {

}
