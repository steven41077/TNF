package hellobitm;

//abstract class
public abstract class shape {
	protected float area;
	
//ab method
	public abstract void calArea();
	
	//solid method 
	public void show()
	{
		System.out.println("Area of the sha[e is "+area);
	}
}
