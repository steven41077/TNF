package example;
import java.util.*;
public class Running {
	//private static final int case 1 = 0;

	public static void main(String[] args) {
		Demo3 c= (Demo3) new Calculator();
		System.out.println("---welcome to my Calculator---");
		System.out.println("===============================");
		Scanner sc=new Scanner(System.in);
		
		
	    while(true) {
	    	System.out.println("1:Addition\n2:subtraction\n3:Multiplication\n4:Divistion");
			int choice=sc.nextInt();
	    	
		    if(choice>=1 && choice<=4) {
		    	System.out.println("Enter the 1st number");
			    int a=sc.nextInt();
			    System.out.println("Enter the 2nd number");
			    int b=sc.nextInt();
				
			}
			
	    	int a=0;
			int b=0;
			switch(choice)
			{
				
				case 1:
					int sum=c.add(a, b);
				    System.out.println("Sum:"+sum);
				   break;
				    
				case 2:
					int sub=c.add(a, b);
				    System.out.println("Sub:"+sub);
				    break;
				    
				case 3:
					 int mul=c.add(a, b);
				    System.out.println("Mul:"+mul);
				    break;
				    
				case 4:
					int div=c.add(a, b);
				    System.out.println("div:"+div);
				    break;
				    
				case 5:
					System.out.println("Thank you Using");
					System.exit(0);
					break;
			    default:
			    	System.out.println("Invalid Chooose");
			}
	    	System.out.println("----------------------------------------");
	    }
		
	
	}
	
}
