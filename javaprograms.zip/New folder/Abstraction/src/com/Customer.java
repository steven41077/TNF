package com;
import java.util.Scanner;
public class Customer {
	public static void main(String[]args)
	{
	
	System.out.println("WELCOME TO ATM");
	System.out.println("-----------------------");
	
	Scanner sc=new Scanner(System.in);
	Bank obj=new Atm();

	while(true)	
	{
		System.out.println("1:despoite\n2:withdraw\n3:checkbalance\n4:extit");
		System.out.println("please enter choose:");
		int Choose=sc.nextInt();
		
		switch(Choose)
		{
	    	case 1:
	    		System.out.println("enter the amount to be deposited");
	    		int dAmt=sc.nextInt();
	    		obj.despoite(dAmt);
	    		break;
	    		
	    	case 2:
	    		System.out.println("enter the amount to be withdraw");
	    		int wAmt=sc.nextInt();
	    		obj.withdraw(wAmt);
	    		break;
	    		
	    	case 3:
	    		obj.checkbalance();
	    	     break;
	    	 
	    	case 4:
	    		System.out.println("THANK YOU FOR VISITING");
	    	  
	    	    
	    	default:
	    		System.out.println("INVALID CHOOICE");
		}
	    	
		
	}
    	
    		
    		
	}

	
			
	
	
	

}
