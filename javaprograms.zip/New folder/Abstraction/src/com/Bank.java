package com;

public interface Bank {
	void despoite(int amount);
	void withdraw(int amount);
	void checkbalance();

}
