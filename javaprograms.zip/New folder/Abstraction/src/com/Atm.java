package com;

public class Atm implements Bank{
	int balance=2000;
	
	@override
	 public void despoite(int amount)
	{
		System.out.println("despoited rs:"+amount);
		balance+=amount;
		System.out.println("amount is deposited successfully");
		
	}
	
	@override
	 public void withdraw(int amount)
	{
		System.out.println("withdraw rs:"+amount);
		balance-=amount;
		System.out.println("amount is withdraw successfully");
	}
	
	public void checkbalance()
	{
		System.out.println("Avaliable balance:"+balance);
		
	}

}
