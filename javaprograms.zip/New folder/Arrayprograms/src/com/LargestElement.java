package com;
import java.util.Scanner;
public class LargestElement {
	public static void main(String[] args)
	{
	@SuppressWarnings("resource")
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the size of an array");
	int size=sc.nextInt();
	int []a=new int[(int) size];
	System.out.println("enter the number");
	for(int i=0; i<size; i++)
	{
		a[i]=(int) sc.nextInt();
	}
	int largest=a[0];
    for(int i=1;i<size;i++)
    {
    	if(a[i]>largest)
    	{
    	
    	largest=a[i];
    	}
    }
    

    int largset11=0;
    System.out.println(largset11);
     }
}