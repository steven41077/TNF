package collectionHierarchy;

import java.util.ArrayList;

public class Demo {
	public static void main(String[] args) {
		ArrayList l=new ArrayList();
		l.add(10);
		l.add(30);
		l.add(10);
		l.add(null);
		l.add("java");
		l.add("util");
		System.out.println(l);
		System.out.println("=================================");
		
		
		System.out.println(l.size());
		System.out.println("=============================");
		System.out.println(l.contains("java"));
		System.out.println(l.contains("Java"));
		
		System.out.println("=============================");
		System.out.println(l);
		l.remove(3);
		System.out.println(l);
		System.out.println("=================================");
		
		System.out.println(l.isEmpty());
		l.clear();
		System.out.println("=================================");
	
		
		ArrayList x=new ArrayList();{
			x.add(12);
			x.add(24);
			x.add(67);
			x.add(24);
			System.out.println(x);
			System.out.println(x.lastIndexOf(67));
			
		}	
			}

}
