package collectionHierarchy;

import java.util.ArrayList;
import java.util.LinkedList;

public class Employee {
	int id;
	String name;
	Employee(int id, String name) {
		this.id = id;
		this.name = name;
	}
	 public String toString()
	 {
		 return id+" "+name;
	 }
	 
  public static void main(String[] args) {
	 
		  Employee e1=new Employee(101, "steven");
		  Employee e2=new Employee(102, "Dynamo");
		  Employee e3=new Employee(103,"mass");
		  
		  
		  LinkedList<Employee> l=new LinkedList<Employee>();
		
			  l.add(e1);
			  l.add(e2);
			  l.add(e3);
		  for(Employee emp:l) {
			  System.out.println(emp);
		  }
      }
}

