package linkedlist;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

@SuppressWarnings("unused")
public class Demo {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		@SuppressWarnings("rawtypes")
		LinkedList l=new LinkedList();
		l.add(10);
		l.add(24);
		l.add(23);
		l.add(34);
		System.out.println(l);
		System.out.println("before storing:");
		for(int i=0;i<l.size();i++)
		{
			System.out.println(l);
		
		}
		Collections.sort(l);
		System.out.println("After storing:");
		for(int i=0;i<l.size();i++)
		{
			System.out.println(l);
		}
		

	
	}

}
